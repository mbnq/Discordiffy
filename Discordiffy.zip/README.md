# Discordiffy
 	This simple script converts video file until it gets under 24.80MB 
 	to fit into free Discord video upload size limit.
	Simply drag'n'drop video file onto script file.
 	This script uses ffmpeg.exe, you can find it on the web.

[Grab it here: ffmpeg-git-full.7z](https://www.gyan.dev/ffmpeg/builds/ffmpeg-git-full.7z)
